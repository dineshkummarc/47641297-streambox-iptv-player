package nemosofts.streambox.interfaces;

public interface SuccessListener {
    void onStart();
    void onEnd(String success);
}